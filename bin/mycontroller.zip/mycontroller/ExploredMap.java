package mycontroller;

import java.util.ArrayList;
import java.util.HashMap;
import tiles.MapTile;
import utilities.Coordinate;
import world.WorldSpatial;
import world.WorldSpatial.Direction;

public class ExploredMap {
	HashMap<Coordinate, MapTile> exploredMap;
	MyAutoController controller;
	private static final int X_POS = 0;
	private static final int Y_POS = 1;
	public ExploredMap(MyAutoController controller)
	{
		this.controller=controller;
		this.exploredMap=new HashMap<Coordinate, MapTile> ();
		intializeMap();
	}
	public void intializeMap()
	{
		HashMap<Coordinate, MapTile> gameMap=controller.getMap();
		for (Coordinate coordinate: gameMap.keySet()) {
			
			exploredMap.put(coordinate, null);
		}
	}
	public void addSubExploredMap ()
	{
		HashMap<Coordinate, MapTile> subMap=controller.getView();
		exploredMap.putAll(subMap);
	}
	public boolean outofbound(int x,int y)
	{
		if(x<0||y<0||x>controller.mapWidth()||y>controller.mapHeight())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//��������currentX,currentY,�����Ե�ǰ����Ϊ���ĵ�9*9��Χ�ڣ�δ֪�����ĸ���
	public int checkInvisibility(int currentX,int currentY)
	{
		int unknownArea=0;
		final int VIEW_SQUARE=4;
		for(int x = currentX - VIEW_SQUARE; x <= currentX+VIEW_SQUARE; x++){
			for(int y = currentY - VIEW_SQUARE; y <= currentY+VIEW_SQUARE; y++){
				if(!outofbound(x,y))
				{
					if(exploredMap.get(new Coordinate(x,y))==null)
					{
						unknownArea++;
					}
				}
			}
		}
		return unknownArea;
	}
	public Coordinate nextStep(String coordinate)
	{
		String[] splitCoordinate = coordinate.split(",");
		int CurrentX = Integer.parseInt(splitCoordinate[X_POS]);
		int CurrentY = Integer.parseInt(splitCoordinate[Y_POS]);
		int maxview=0;
		Coordinate nextStep=null;
		int x=CurrentX;
		int y=CurrentY-1;
		if(!outofbound(x,y)&&!exploredMap.get(new Coordinate(x,y)).isType(MapTile.Type.WALL))
		{
			if(maxview<checkInvisibility(x,y))
			{
			maxview=checkInvisibility(x,y);
			nextStep=new Coordinate(x,y);
			}
		}
		y=y+2;
		if(!outofbound(x,y)&&!exploredMap.get(new Coordinate(x,y)).isType(MapTile.Type.WALL))
		{
			if(maxview<checkInvisibility(x,y))
			{
			maxview=checkInvisibility(x,y);
			nextStep=new Coordinate(x,y);
			}
		}
		x--;
		y=CurrentY;
		if(!outofbound(x,y)&&!exploredMap.get(new Coordinate(x,y)).isType(MapTile.Type.WALL))
		{
			if(maxview<checkInvisibility(x,y))
			{
			maxview=checkInvisibility(x,y);
			nextStep=new Coordinate(x,y);
			}
		}
		x=x+2;
		if(!outofbound(x,y)&&!exploredMap.get(new Coordinate(x,y)).isType(MapTile.Type.WALL))
		{
			if(maxview<checkInvisibility(x,y))
			{
			maxview=checkInvisibility(x,y);
			nextStep=new Coordinate(x,y);
			}
		}
		return nextStep;
	}
}
