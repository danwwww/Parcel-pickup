package mycontroller;

import controller.CarController;
import world.Car;
import java.util.HashMap;

import tiles.MapTile;
import utilities.Coordinate;
import mycontroller.Pace;
import mycontroller.AutoDriver;
import mycontroller.ExploredMap;

public class MyAutoController extends CarController{		
		
		private Pace paces;
		private AutoDriver driver;
		private ExploredMap exploredMap=new ExploredMap(this);
		// Car Speed to move at
		private final int CAR_MAX_SPEED = 1;
		
		public MyAutoController(Car car) {
			super(car);
			exploredMap.addSubExploredMap();
			this.paces = new Pace();
			this.driver =  new AutoDriver(this);
		}
		
		public void update() {
			Coordinate nextPostion = exploredMap.nextStep(this.getPosition());
			paces.push(nextPostion);
			this.driver.moveTo(nextPostion);
			exploredMap.addSubExploredMap();
			
		}
		
		
	}
