package mycontroller;
import java.util.ArrayList;
import utilities.Coordinate;

public class Pace {
	public ArrayList<Coordinate> coordinates;
	public Pace(ArrayList<Coordinate> coordinates)
	{
		this.coordinates=coordinates;
	}
	public Pace()
	{
		coordinates= new ArrayList<Coordinate>();
	}
	public void push(Coordinate coordinate)
	{
		coordinates.add(coordinate);
	}
	public Coordinate pop()
	{
		if(!coordinates.isEmpty())
		{
			int length=coordinates.size();
			return coordinates.remove(length-1);
		}
		return null;
	}
	public boolean isempty()
	{
		return coordinates.isEmpty();
	}
}
